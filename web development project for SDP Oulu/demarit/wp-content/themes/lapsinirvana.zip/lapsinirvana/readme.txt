Nirvana WordPress Theme, Copyright 2014 Cryout Creations
Nirvana WordPress Theme is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/copyleft/gpl.html .

Nirvana WordPress Theme bundles the following third-party resources:

Nivo Slider, Copyright 2010 Gilbert Pellegrom 
Nivo Slider is licensed under the terms of the MIT license 
Source: http://dev7studios.com/nivo-slider

FitVids, Copyright 2011 Chris Coyier - http://css-tricks.com + Dave Rupert - http://daverupert.com
FitVids is licensed under the terms of the WTFPLlicense 
Source: http://fitvidsjs.com/

The extra fonts incuded with the theme are also under GPLv3 compatible licenses as follows:

Source Sans Pro, Copyright 2010, 2012 Paul D. Hunt
Source Sans Pro is licensed under the SIL Open Font License, Version 1.1.
Source: https://www.google.com/fonts/specimen/Source+Sans+Pro

Ubuntu, Copyright 2010 Dalton Maag
Ubuntu is licensed under the SIL Open Font License, Version 1.0.
Source: http://www.google.com/fonts/specimen/Ubuntu

Open Sans, Copyright Steve Matteson
Open Sans is licensed under the Apache License v2.00
Source: https://www.google.com/fonts/specimen/Open+Sans

Droid Sans, Copyright Steve Matteson
Droid Sans is licensed under the Apache License v2.00
Source: https://www.google.com/fonts/specimen/Droid+Sans

Oswald, Copyright 2011-2012 Vernon Adams
Oswald is licensed under the SIL Open Font License, Version 1.1
Source: https://www.google.com/fonts/specimen/Oswald

Yanone Kaffeesatz, Copyright 2010, Jan Gerner
Yanone Kaffeesatz is licensed under the SIL Open Font License, Version 1.1
Source: https://www.google.com/fonts/specimen/Yanone+Kaffeesatz

Elusive-Icons Webfont, Copyright 2013, Aristeides Stathopoulos
Elusive-Icons Webfont is licensed under the SIL Open Font License, Version 1.1
Source: http://shoestrap.org/downloads/elusive-icons-webfont/

Font Awesome, Copyright Dave Gandy
Font Awesome is dual-licensed under the terms of the SIL Open Font License, Version 1.1, and the MIT license
Source: http://fortawesome.github.io/Font-Awesome/

"Tablet Ipad screen internet browser online" image, Copyright 2013 realworkhard
"Tablet Ipad screen internet browser online" is licensed under the terms of the Public Domain CC0 License
Source: http://pixabay.com/en/tablet-ipad-screen-internet-184888/ 

All other images bundled with the theme (used in the demo presentation page and admin section, as well as the social icons) are created by Cryout Creations and released with the theme under GPLv3 as well.

Translations credits:
German - ralflexis 
Russian - Alexander